# IR_Pylucene

A simple search system with Pylucene.
